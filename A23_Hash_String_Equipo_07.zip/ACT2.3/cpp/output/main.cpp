/**
 * @file main.cpp
 * @authors Daniel Hurtaodo (A01707774), Gamaliel Marines (A017087467), Carlos Velasco
 * @brief Hashing algorithm
 * @version 0.1
 * @date 2023-09-21
 * 
 * @copyright Copyright (c) 2023
 * @run g++ -std=c++11 main.cpp -o main && ./main
 */


#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
#include <sstream>

using namespace std;

void mostrarError(const string& mensaje) {
    cerr << "Error: " << mensaje << endl;
}

void mostrarMensaje(const string& mensaje) {
    cout << mensaje << endl;
}

void crearArchivo(const string& filename, const string& content) {
    ofstream file(filename);
    if (!file) {
        cerr << "Error: No se pudo crear o abrir el archivo " << filename << ". Razón: " << strerror(errno) << endl;
        return;
    }

    file << content;
    file.close();
    cout << "Archivo " << filename << " creado exitosamente." << endl;
}


string calcularHash(const string& filename, int n) {
    ifstream file(filename);

    if (!file) {
        mostrarError("No se pudo abrir el archivo: " + filename);
        exit(1);
    }

    vector<int> column_sums(n, 0);
    vector<vector<char>> table;

    char c;
    vector<char> currentRow;

    while (file.get(c)) {
        currentRow.push_back(c);
        if (currentRow.size() == n) {
            table.push_back(currentRow);
            currentRow.clear();
        }
    }

    if (!currentRow.empty()) {
        while (currentRow.size() < n) {
            currentRow.push_back(static_cast<char>(n));
        }
        table.push_back(currentRow);
    }

    file.close();

    cout << "Tabla Generada:\n";
    for (const auto& row : table) {
        for (char elem : row) {
            cout << elem;
        }
        cout << endl;
    }
    cout << endl;

    for (const auto& row : table) {
        for (int j = 0; j < n; ++j) {
            column_sums[j] += static_cast<int>(row[j]);
        }
    }

    stringstream hash_stream;
    for (int i = 0; i < n/4; ++i) {
        hash_stream << setw(2) << setfill('0') << hex << (column_sums[i] % 256);
    }

    cout << "Arreglo a:" << endl;
    for (int i = 0; i < n; ++i) {
        cout << setw(2) << setfill('0') << hex << uppercase << (column_sums[i] % 256) << " ";
    }
    cout << endl;

    return hash_stream.str();
}

bool runTest(const string& filename, int n, const string& expectedHash) {
    string result = calcularHash(filename, n);
    if (result == expectedHash) {
        cout << "Test para " << filename << " con n = " << n << " PASÓ." << endl;
        return true;
    } else {
        cout << "Test para " << filename << " con n = " << n << " FALLÓ. Esperado: " << expectedHash << " Obtenido: " << result << endl;
        return false;
    }
}

void runAllTests() {
    // Crear archivos de prueba
    crearArchivo("empty.txt", "");
    crearArchivo("exact.txt", "ABCDEFGHIJKLMNOP");
    crearArchivo("large.txt", "ABCDEFGHIJKLMNOPQRSTUVWXYYZabcdefghijklmnopqrstuvwxyyz123456");
    crearArchivo("lines.txt", "ABCD\nEFGH\nIJKL\nMNOP");

    // Ejecutar las pruebas
    runTest("empty.txt", 16, "00000000");
    runTest("exact.txt", 16, ""); // El hash esperado puede cambiar basado en la suma de los ASCII
    runTest("large.txt", 32, ""); // De manera similar, el hash puede cambiar
    runTest("lines.txt", 16, ""); // El hash puede cambiar basado en la suma ASCII
}

int main() {
    int opcion;
    string filename;
    int n;
    cout << "Elija una opción:" << endl;
    cout << "1. Crear archivos de prueba." << endl;
    cout << "2. Calcular hash." << endl;
    cout << "3. Ejecutar pruebas unitarias." << endl;
    cin >> opcion;
    string hash = calcularHash(filename, n);


    switch(opcion) {
        case 1:
            // Crear archivos de prueba
            crearArchivo("empty.txt", "");
            crearArchivo("exact.txt", "ABCDEFGHIJKLMNOP");
            crearArchivo("large.txt", "ABCDEFGHIJKLMNOPQRSTUVWXYYZabcdefghijklmnopqrstuvwxyyz123456");
            crearArchivo("lines.txt", "ABCD\nEFGH\nIJKL\nMNOP");
            break;
        case 2: {
            mostrarMensaje("Ingrese el nombre del archivo de texto: ");
            cin >> filename;

            mostrarMensaje("Ingrese el valor de n (debe ser múltiplo de 4 y estar en el rango [16, 64]): ");
            cin >> n;

            if (n % 4 != 0 || n < 16 || n > 64) {
                mostrarError("El valor de n no es válido. Debe ser múltiplo de 4 y estar en el rango [16, 64].");
                return 1;
            }

            string hash = calcularHash(filename, n); 
            mostrarMensaje("Hash calculado: " + hash);
            break;
        }
        case 3:
            runAllTests();
            break;
        default:
            mostrarError("Opción no válida.");
            break;
    }

    return 0;
}
